import type { NSosyalPort, NSosyalPost, NSosyalProfile } from "./port";

export class MockNSosyalAdapter implements NSosyalPort {
  constructor(private readonly posts: NSosyalPost[], private readonly profiles: NSosyalProfile[]) {}

  async getPost(postId: string) {
    const post = this.posts.find((item) => item.id === postId);
    if (!post) throw new Error("Post not found");
    if (!post.projectAnalysisConsent) throw new Error("Project analysis consent is required");
    return post;
  }

  async getProfile(profileId: string) {
    const profile = this.profiles.find((item) => item.id === profileId);
    if (!profile) throw new Error("Profile not found");
    return profile;
  }

  async publishProjectCard(postId: string, projectId: string) {
    void postId;
    void projectId;
    return;
  }
}
