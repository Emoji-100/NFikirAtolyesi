export type NSosyalPost = {
  id: string;
  authorId: string;
  text: string;
  createdAt: string;
  projectAnalysisConsent: boolean;
};

export type NSosyalProfile = {
  id: string;
  displayName: string;
  handle: string;
  declaredSkills: string[];
  availabilityHoursPerWeek?: number;
};

export interface NSosyalPort {
  getPost(postId: string): Promise<NSosyalPost>;
  getProfile(profileId: string): Promise<NSosyalProfile>;
  publishProjectCard(postId: string, projectId: string): Promise<void>;
}

export class NSosyalIntegrationNotConfiguredError extends Error {
  constructor() {
    super("Official NSosyal API documentation and credentials are required before live integration can be enabled.");
    this.name = "NSosyalIntegrationNotConfiguredError";
  }
}
