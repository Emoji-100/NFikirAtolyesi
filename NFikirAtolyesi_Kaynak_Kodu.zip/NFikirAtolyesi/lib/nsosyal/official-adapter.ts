import { NSosyalIntegrationNotConfiguredError, type NSosyalPort, type NSosyalPost, type NSosyalProfile } from "./port";

/**
 * Deliberately contains no guessed endpoints. The competition prototype uses
 * its own consented demo data. When NSosyal supplies an official base URL,
 * OAuth scopes, endpoint map and webhook contract, only this adapter changes.
 */
export class OfficialNSosyalAdapter implements NSosyalPort {
  async getPost(postId: string): Promise<NSosyalPost> {
    void postId;
    throw new NSosyalIntegrationNotConfiguredError();
  }

  async getProfile(profileId: string): Promise<NSosyalProfile> {
    void profileId;
    throw new NSosyalIntegrationNotConfiguredError();
  }

  async publishProjectCard(postId: string, projectId: string): Promise<void> {
    void postId;
    void projectId;
    throw new NSosyalIntegrationNotConfiguredError();
  }
}
