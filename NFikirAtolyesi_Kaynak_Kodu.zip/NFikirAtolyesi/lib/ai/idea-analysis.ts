export type IdeaAnalysis = {
  problem: string;
  solution: string;
  targetAudience: string;
  domain: string;
  skills: string[];
};

const domainRules = [
  {
    words: ["engelli", "erişilebilir", "sesli", "işaret dili", "altyazı"],
    domain: "Erişilebilirlik",
    problem: "Fiziksel veya dijital hizmetlere eşit erişimin sağlanamaması",
    audience: "Erişilebilirlik ihtiyacı bulunan kullanıcılar ve destekleyici topluluklar",
    skills: ["Erişilebilirlik", "UI/UX", "Kullanıcı testleri"],
  },
  {
    words: ["öğrenci", "okul", "eğitim", "öğretmen", "ders", "mentör"],
    domain: "Eğitim teknolojileri",
    problem: "Öğrencilerin nitelikli eğitim kaynağına veya uzman desteğine erişim açığı",
    audience: "Öğrenciler, eğitimciler ve öğrenme toplulukları",
    skills: ["Eğitim tasarımı", "Web geliştirme", "Kullanıcı araştırması"],
  },
  {
    words: ["atık", "çevre", "gıda", "geri dönüşüm", "iklim", "enerji"],
    domain: "Sürdürülebilirlik",
    problem: "Kaynakların verimsiz kullanılması ve yerel çevresel etkinin büyümesi",
    audience: "Yerel topluluklar, işletmeler ve gönüllü ağları",
    skills: ["Etki ölçümü", "Mobil geliştirme", "Topluluk yönetimi"],
  },
  {
    words: ["afet", "deprem", "yangın", "sel", "acil"],
    domain: "Afet dayanıklılığı",
    problem: "Afet öncesi hazırlık ve afet anındaki koordinasyon bilgisinin dağınık kalması",
    audience: "Yerel topluluklar, gönüllüler ve saha ekipleri",
    skills: ["Kriz koordinasyonu", "Harita sistemleri", "Doğrulama tasarımı"],
  },
  {
    words: ["tarım", "çiftçi", "ürün", "sulama", "köy"],
    domain: "Tarım ve kırsal kalkınma",
    problem: "Kırsal üreticilerin bilgiye, pazara veya verimli kaynak kullanımına erişim açığı",
    audience: "Çiftçiler, kooperatifler ve kırsal girişimler",
    skills: ["Saha araştırması", "Veri analizi", "İş modeli"],
  },
  {
    words: ["sağlık", "hasta", "doktor", "psikoloji", "bakım"],
    domain: "Toplum sağlığı",
    problem: "Koruyucu sağlık bilgisine ve uygun desteğe zamanında erişim güçlüğü",
    audience: "Desteğe ihtiyaç duyan bireyler, yakınları ve sağlık toplulukları",
    skills: ["Sağlık iletişimi", "Gizlilik tasarımı", "Kullanıcı araştırması"],
  },
];

function compact(text: string, maxLength = 220) {
  const normalized = text.replace(/\s+/g, " ").trim();
  return normalized.length > maxLength ? `${normalized.slice(0, maxLength - 3).trimEnd()}...` : normalized;
}

export function analyzeIdea(content: string): IdeaAnalysis {
  const lowered = content.toLocaleLowerCase("tr-TR");
  const match = domainRules.find((rule) => rule.words.some((word) => lowered.includes(word)));
  return {
    problem: match?.problem ?? "Paylaşımda tarif edilen toplumsal ihtiyacın doğrulanması",
    solution: compact(content),
    targetAudience: match?.audience ?? "Problemi doğrudan yaşayan kullanıcılar ve ilgili topluluklar",
    domain: match?.domain ?? "Sosyal inovasyon",
    skills: match?.skills ?? ["Problem doğrulama", "Ürün geliştirme", "UI/UX"],
  };
}
