import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  metadataBase: new URL("https://nfikir-atolyesi.camsaadetbusra.chatgpt.site"),
  title: "NFikirAtölyesi",
  description:
    "NSosyal paylaşımlarını yapılandırılmış fikirlere, tamamlayıcı ekiplere ve uygulanabilir proje yol haritalarına dönüştüren sosyal yapay zekâ prototipi.",
  openGraph: {
    title: "NFikirAtölyesi | Fikirlerden projelere",
    description:
      "Fikrini yapılandır, tamamlayıcı insanları bul ve NSosyal topluluğuyla birlikte harekete geç.",
    type: "website",
    images: [
      {
        url: "/og.png",
        width: 1200,
        height: 630,
        alt: "NFikirAtölyesi, fikirlerden projelere",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "NFikirAtölyesi | Fikirlerden projelere",
    description:
      "Fikrini yapılandır, tamamlayıcı insanları bul ve birlikte harekete geç.",
    images: ["/og.png"],
  },
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="tr">
      <body className="antialiased">{children}</body>
    </html>
  );
}
