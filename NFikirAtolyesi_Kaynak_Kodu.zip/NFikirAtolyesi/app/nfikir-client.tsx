"use client";

import { FormEvent, useEffect, useMemo, useState } from "react";

type IdeaSource = "demo" | "pilot" | "session";

type Idea = {
  id: string;
  author: string;
  handle: string;
  initials: string;
  avatar: "blue" | "cyan" | "violet" | "orange";
  time: string;
  text: string;
  problem: string;
  solution: string;
  audience: string;
  domain: string;
  skills: string[];
  stage: string;
  matches: number;
  support: number;
  source: IdeaSource;
};

type StoredIdea = {
  id: string;
  ownerName: string;
  content: string;
  problem: string;
  solution: string;
  targetAudience: string;
  domain: string;
  stage: string;
  skillsJson: string;
  createdAt: string;
};

const seedIdeas: Idea[] = [
  {
    id: "idea-lab", author: "Deniz Aksoy", handle: "@denizuretiyor", initials: "DA", avatar: "violet", time: "12 dk",
    text: "Kırsal bölgelerdeki öğrencilerin deney yapabilmesi için düşük maliyetli, tarayıcı üzerinden çalışan bir sanal laboratuvar geliştirmek istiyorum. Eğitimci ve yazılımcı arıyorum.",
    problem: "Deney altyapısına erişim eşitsizliği", solution: "Düşük donanımda çalışan etkileşimli sanal laboratuvar", audience: "Kırsal bölgedeki ortaöğretim öğrencileri", domain: "Eğitim teknolojileri", skills: ["Web geliştirme", "UI/UX", "Eğitim tasarımı"], stage: "Fikir doğrulama", matches: 8, support: 64, source: "demo",
  },
  {
    id: "idea-food", author: "Ece Yıldırım", handle: "@eceyesil", initials: "EY", avatar: "cyan", time: "31 dk",
    text: "Mahallelerdeki market ve kafelerin gün sonunda kalan ürünlerini öğrenci topluluklarıyla buluşturan bir gıda paylaşım haritası tasarlıyorum. Lojistik tarafını bilen biri var mı?",
    problem: "Tüketilebilir gıdanın atığa dönüşmesi", solution: "Konum ve zaman tabanlı topluluk paylaşım haritası", audience: "Yerel işletmeler ve öğrenci toplulukları", domain: "Sürdürülebilirlik", skills: ["Mobil geliştirme", "Lojistik", "Topluluk yönetimi"], stage: "Ekip arıyor", matches: 5, support: 41, source: "demo",
  },
  {
    id: "idea-access", author: "Mert Can", handle: "@merttasarlar", initials: "MC", avatar: "orange", time: "1 sa",
    text: "Görme engelli öğrenciler için kampüs içindeki geçici engelleri topluluk verisiyle bildiren sesli yönlendirme sistemi üzerine çalışıyorum. Erişilebilirlik uzmanı arıyorum.",
    problem: "Kampüsteki geçici engellerin erişilebilir rotalara yansımaması", solution: "Topluluk doğrulamalı, sesli ve dinamik yönlendirme", audience: "Görme engelli üniversite öğrencileri", domain: "Erişilebilirlik", skills: ["Erişilebilirlik", "Harita sistemleri", "Mobil geliştirme"], stage: "İlk prototip", matches: 11, support: 89, source: "demo",
  },
];

const candidates = [
  { name: "Selin Kaya", role: "Frontend geliştirici", initials: "SK", score: 94, reason: "Web geliştirme + eğitim teknolojileri" },
  { name: "Arda Demir", role: "UI/UX tasarımcısı", initials: "AD", score: 89, reason: "Erişilebilir arayüz + kullanıcı araştırması" },
  { name: "İrem Şahin", role: "Fen bilimleri öğretmeni", initials: "İŞ", score: 86, reason: "İçerik doğrulama + hedef kitle deneyimi" },
];

const roadmap = [
  { title: "5 öğrenci ve 2 öğretmenle problem görüşmesi", owner: "Deniz", week: "1. hafta" },
  { title: "İlk üç deney için içerik kapsamı", owner: "İrem", week: "1. hafta" },
  { title: "Etkileşimli prototip ve kullanıcı akışı", owner: "Selin + Arda", week: "2. hafta" },
  { title: "Kullanılabilirlik testi ve başarı ölçümü", owner: "Tüm ekip", week: "3. hafta" },
];

const tabs = ["Akış", "Analiz", "Eşleşmeler", "Proje Odası"];
const tabIcons = ["home", "spark", "people", "board"];

function Icon({ name, size = 20 }: { name: string; size?: number }) {
  const paths: Record<string, React.ReactNode> = {
    home: <><path d="M3 11.5 12 4l9 7.5"/><path d="M5.5 10.5V21h13V10.5M9.5 21v-6h5v6"/></>,
    spark: <><path d="m12 3 1.6 5.4L19 10l-5.4 1.6L12 17l-1.6-5.4L5 10l5.4-1.6L12 3Z"/><path d="m5 16 .7 2.3L8 19l-2.3.7L5 22l-.7-2.3L2 19l2.3-.7L5 16Z"/></>,
    people: <><circle cx="9" cy="8" r="3"/><path d="M3.5 19c.4-4 2.2-6 5.5-6s5.1 2 5.5 6"/><circle cx="17" cy="9" r="2.3"/><path d="M15.5 14.2c3.2-.6 5 1 5.5 4.2"/></>,
    board: <><rect x="3" y="4" width="18" height="16" rx="3"/><path d="M8 8h8M8 12h8M8 16h5"/></>,
    search: <><circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/></>,
    bell: <><path d="M18 9a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9Z"/><path d="M10 21h4"/></>,
    heart: <path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1.1-1.1a5.5 5.5 0 0 0-7.8 7.8l1.1 1.1L12 21l7.8-7.5 1.1-1.1a5.5 5.5 0 0 0-.1-7.8Z"/>,
    arrow: <><path d="M5 12h14M13 6l6 6-6 6"/></>,
    check: <path d="m5 12 4 4L19 6"/>,
    shield: <><path d="M12 3 4.5 6v5.5c0 4.7 3 8.1 7.5 9.5 4.5-1.4 7.5-4.8 7.5-9.5V6L12 3Z"/><path d="m8.5 12 2.2 2.2 4.8-5"/></>,
    plus: <><path d="M12 5v14M5 12h14"/></>,
    close: <><path d="m6 6 12 12M18 6 6 18"/></>,
    data: <><ellipse cx="12" cy="5" rx="8" ry="3"/><path d="M4 5v6c0 1.7 3.6 3 8 3s8-1.3 8-3V5M4 11v6c0 1.7 3.6 3 8 3s8-1.3 8-3v-6"/></>,
  };
  return <svg aria-hidden="true" className="icon" viewBox="0 0 24 24" width={size} height={size} fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">{paths[name]}</svg>;
}

function initialsFor(name: string) {
  return name.split(/\s+/).filter(Boolean).slice(0, 2).map((part) => part[0]).join("").toLocaleUpperCase("tr-TR");
}

function storedToIdea(row: StoredIdea): Idea {
  let skills: string[] = [];
  try { skills = JSON.parse(row.skillsJson) as string[]; } catch { skills = ["Kullanıcı araştırması"]; }
  return {
    id: row.id, author: row.ownerName, handle: "@pilotkatilimci", initials: initialsFor(row.ownerName), avatar: "blue", time: "pilot kaydı", text: row.content,
    problem: row.problem, solution: row.solution, audience: row.targetAudience, domain: row.domain, skills, stage: row.stage || "Yeni fikir", matches: Math.max(1, skills.length), support: 0, source: "pilot",
  };
}

export default function NFikirClient() {
  const [activeTab, setActiveTab] = useState("Akış");
  const [ideas, setIdeas] = useState(seedIdeas);
  const [selectedId, setSelectedId] = useState(seedIdeas[0].id);
  const [completed, setCompleted] = useState<number[]>([]);
  const [invited, setInvited] = useState<string[]>([]);
  const [supported, setSupported] = useState<string[]>([]);
  const [notice, setNotice] = useState("");
  const [composerOpen, setComposerOpen] = useState(false);
  const [draft, setDraft] = useState("");
  const [query, setQuery] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [pilotCount, setPilotCount] = useState(0);
  const [dataState, setDataState] = useState<"loading" | "connected" | "offline">("loading");

  useEffect(() => {
    let cancelled = false;
    async function loadPilotIdeas() {
      try {
        const response = await fetch("/api/ideas", { headers: { accept: "application/json" } });
        if (!response.ok) throw new Error("pilot data unavailable");
        const payload = await response.json() as { ideas?: StoredIdea[] };
        const stored = (payload.ideas ?? []).map(storedToIdea);
        if (!cancelled) {
          setPilotCount(stored.length);
          setDataState("connected");
          setIdeas((current) => [...stored, ...current.filter((idea) => !stored.some((row) => row.id === idea.id))]);
        }
      } catch {
        if (!cancelled) setDataState("offline");
      }
    }
    void loadPilotIdeas();
    return () => { cancelled = true; };
  }, []);

  const selected = useMemo(() => ideas.find((idea) => idea.id === selectedId) ?? ideas[0], [ideas, selectedId]);
  const filteredIdeas = useMemo(() => {
    const clean = query.trim().toLocaleLowerCase("tr-TR");
    if (!clean) return ideas;
    return ideas.filter((idea) => `${idea.text} ${idea.domain} ${idea.author}`.toLocaleLowerCase("tr-TR").includes(clean));
  }, [ideas, query]);
  const domainCounts = useMemo(() => {
    const counts = new Map<string, number>();
    ideas.forEach((idea) => counts.set(idea.domain, (counts.get(idea.domain) ?? 0) + 1));
    return [...counts.entries()].sort((a, b) => b[1] - a[1]).slice(0, 3);
  }, [ideas]);
  const openSkills = useMemo(() => new Set(ideas.flatMap((idea) => idea.skills)).size, [ideas]);
  const clarity = selected ? Math.min(94, 68 + Math.round(Math.min(selected.text.length, 260) / 12)) : 0;

  function selectIdea(id: string) {
    setSelectedId(id);
    setActiveTab("Analiz");
    setNotice("Fikir kartı oluşturuldu. Yapay zekâ alanlarının tamamı kullanıcı tarafından düzenlenebilir.");
  }

  function toggleSupport(id: string) {
    const isSupported = supported.includes(id);
    setSupported((list) => isSupported ? list.filter((item) => item !== id) : [...list, id]);
    setIdeas((current) => current.map((idea) => idea.id === id ? { ...idea, support: Math.max(0, idea.support + (isSupported ? -1 : 1)) } : idea));
  }

  async function createIdea(event: FormEvent) {
    event.preventDefault();
    const clean = draft.trim();
    if (clean.length < 20) { setNotice("Fikri analiz edebilmemiz için en az 20 karakter yazmalısın."); return; }
    setSubmitting(true);
    try {
      const response = await fetch("/api/ideas", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ content: clean, ownerName: "Emirhan Eken", ownerId: "demo-emirhan" }) });
      if (!response.ok) throw new Error("persistence unavailable");
      const payload = await response.json() as { idea: { id: string; content: string; problem: string; solution: string; targetAudience: string; domain: string; skills: string[] } };
      const idea: Idea = {
        id: payload.idea.id, author: "Emirhan Eken", handle: "@emirhaneken", initials: "EE", avatar: "blue", time: "şimdi", text: payload.idea.content,
        problem: payload.idea.problem, solution: payload.idea.solution, audience: payload.idea.targetAudience, domain: payload.idea.domain, skills: payload.idea.skills,
        stage: "Yeni fikir", matches: Math.max(1, payload.idea.skills.length), support: 0, source: "pilot",
      };
      setIdeas((current) => [idea, ...current]);
      setPilotCount((count) => count + 1);
      setDataState("connected");
      setSelectedId(idea.id);
      setNotice("Pilot fikri kalıcı olarak kaydedildi, analiz edildi ve eşleşme kuyruğuna alındı.");
    } catch {
      const idea: Idea = {
        id: `session-${Date.now()}`, author: "Emirhan Eken", handle: "@emirhaneken", initials: "EE", avatar: "blue", time: "şimdi", text: clean,
        problem: "Kullanıcı tarafından tanımlanan problemin doğrulanması", solution: clean, audience: "Hedef kullanıcı araştırması gerekli", domain: "Sosyal inovasyon",
        skills: ["Problem doğrulama", "Ürün geliştirme", "Kullanıcı araştırması"], stage: "Oturum taslağı", matches: 3, support: 0, source: "session",
      };
      setIdeas((current) => [idea, ...current]);
      setSelectedId(idea.id);
      setNotice("Fikir bu oturuma eklendi. Kalıcı pilot veri bağlantısı geçici olarak kullanılamıyor.");
    } finally {
      setDraft(""); setComposerOpen(false); setActiveTab("Analiz"); setSubmitting(false);
    }
  }

  return (
    <main className="app-shell">
      <aside className="sidebar" aria-label="Ana navigasyon">
        <div className="brand-lockup"><span className="nsosyal-mark">N</span><div><strong>NSosyal</strong><small>NFikirAtölyesi</small></div></div>
        <div className="integration-chip"><span className="live-dot" /> Entegrasyon prototipi</div>
        <nav>{tabs.map((tab, index) => <button className={`nav-item ${activeTab === tab ? "active" : ""}`} key={tab} onClick={() => setActiveTab(tab)}><span className="nav-icon"><Icon name={tabIcons[index]} /></span><span>{tab}</span>{tab === "Eşleşmeler" && <span className="nav-count">{candidates.length}</span>}</button>)}</nav>
        <div className="sidebar-bottom"><div className="privacy-card"><Icon name="shield" size={22} /><div><strong>İzin temelli analiz</strong><p>Yalnızca kullanıcının seçtiği içerik işlenir.</p></div></div><div className="profile-row"><span className="avatar blue">EE</span><div><strong>Emirhan Eken</strong><small>Ürün ve proje lideri</small></div><span className="more">•••</span></div></div>
      </aside>

      <section className="workspace">
        <header className="topbar">
          <div className="mobile-brand"><span className="nsosyal-mark">N</span><strong>NFikirAtölyesi</strong></div>
          <label className="search-box"><Icon name="search" size={18} /><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Fikirlerde ve alanlarda ara" aria-label="Fikirlerde ara" />{query && <button onClick={() => setQuery("")} aria-label="Aramayı temizle"><Icon name="close" size={15} /></button>}</label>
          <div className="top-actions"><button className="icon-button" aria-label="Bildirimler"><Icon name="bell" size={20} /><span /></button><button className="primary-button" onClick={() => setComposerOpen(true)}><Icon name="plus" size={17} /> Fikrini paylaş</button></div>
        </header>

        {notice && <div className="notice" role="status"><Icon name="spark" size={17} /><span>{notice}</span><button onClick={() => setNotice("")} aria-label="Bildirimi kapat"><Icon name="close" size={16} /></button></div>}

        {activeTab === "Akış" && (
          <div className="feed-layout">
            <section className="feed-column" aria-label="Fikir paylaşımları">
              <div className="feed-heading"><div><p className="eyebrow">NFİKİRATÖLYESİ</p><h1>Fikirlerden projelere</h1><p>NSosyal topluluğundaki fikirleri yapılandır, tamamlayıcı insanları bul ve birlikte harekete geç.</p></div><span className={`data-badge ${dataState}`}><span />{dataState === "connected" ? "Pilot veri bağlı" : dataState === "loading" ? "Veri yükleniyor" : "Demo modu"}</span></div>
              <div className="idea-circles" aria-label="Fikir alanları">{["Tümü", ...domainCounts.map(([domain]) => domain)].map((domain, index) => <button key={domain} onClick={() => setQuery(domain === "Tümü" ? "" : domain)} className={!query && index === 0 ? "active" : ""}><span className={`circle-avatar tone-${index % 4}`}>{domain === "Tümü" ? "✦" : initialsFor(domain)}</span><small>{domain}</small></button>)}</div>
              <div className="composer-inline" role="button" tabIndex={0} onClick={() => setComposerOpen(true)} onKeyDown={(event) => { if (event.key === "Enter" || event.key === " ") setComposerOpen(true); }}><span className="avatar blue">EE</span><span>Bir fikrin mi var? NSosyal paylaşımını projeye dönüştür.</span><button className="mini-primary">Paylaş</button></div>
              {filteredIdeas.length === 0 && <div className="empty-state"><Icon name="search" size={25} /><strong>Bu aramayla eşleşen fikir bulunamadı</strong><button onClick={() => setQuery("")}>Tüm fikirleri göster</button></div>}
              {filteredIdeas.map((idea) => (
                <article className={`post-card ${selectedId === idea.id ? "selected" : ""}`} key={idea.id}>
                  <div className="post-head"><span className={`avatar ${idea.avatar}`}>{idea.initials}</span><div><strong>{idea.author}</strong><span>{idea.handle} · {idea.time}</span></div><span className={`source-pill ${idea.source}`}>{idea.source === "demo" ? "Demo senaryosu" : idea.source === "pilot" ? "Pilot kaydı" : "Oturum kaydı"}</span><button className="more-button" aria-label="Gönderi menüsü">•••</button></div>
                  <p className="post-text">{idea.text}</p>
                  <div className="tag-row"><button onClick={() => setQuery(idea.domain)}>#{idea.domain.replaceAll(" ", "")}</button><span>{idea.stage}</span></div>
                  <div className="post-actions"><button className={supported.includes(idea.id) ? "supported" : ""} onClick={() => toggleSupport(idea.id)}><Icon name="heart" size={17} /> {idea.support}</button><span><Icon name="people" size={17} /> {idea.matches} olası katkı</span><button className="convert-button" onClick={() => selectIdea(idea.id)}><Icon name="spark" size={16} /> Projeye dönüştür <Icon name="arrow" size={15} /></button></div>
                </article>
              ))}
            </section>

            <aside className="insight-column">
              <div className="pilot-panel"><div className="pilot-orbit"><span className="nsosyal-mark small">N</span><i /><i /><i /></div><p className="eyebrow light">CANLI ÖLÇÜM ALANI</p><h2>Gerçek kullanım verisi burada oluşur.</h2><p>Yeni fikirler kaydedildikçe sayaçlar doğrudan sistem kayıtlarından güncellenir.</p><div className="pilot-metrics"><div><strong>{pilotCount}</strong><span>kalıcı pilot fikri</span></div><div><strong>{invited.length}</strong><span>hazırlanan davet</span></div><div><strong>{completed.length}</strong><span>tamamlanan görev</span></div></div><button onClick={() => setComposerOpen(true)}>Pilot fikri ekle <Icon name="arrow" size={15} /></button></div>
              <div className="insight-card"><div className="section-title"><h3>Yükselen alanlar</h3><span>Mevcut veri seti</span></div>{domainCounts.map(([item, count], index) => <button className="trend-row" key={item} onClick={() => setQuery(item)}><span>{index + 1}</span><div><strong>{item}</strong><small>{count} kayıt</small></div><b>↗</b></button>)}</div>
              <div className="insight-card metrics-card"><div><strong>{ideas.length}</strong><span>toplam fikir</span></div><div><strong>{openSkills}</strong><span>yetkinlik alanı</span></div><div><strong>{pilotCount}</strong><span>pilot kayıt</span></div></div>
              <div className="data-note"><Icon name="data" size={20} /><p><strong>Veri şeffaflığı</strong> Başlangıçtaki üç içerik demo senaryosudur. “Pilot kaydı” etiketi taşıyan içerikler gerçek kullanıcı girişlerinden oluşur.</p></div>
            </aside>
          </div>
        )}

        {activeTab === "Analiz" && selected && (
          <div className="analysis-layout">
            <section className="analysis-main"><div className="analysis-hero"><div className="analysis-copy"><span className={`source-pill ${selected.source}`}>{selected.source === "pilot" ? "Pilot veriden üretildi" : selected.source === "demo" ? "Demo senaryosu" : "Oturum kaydı"}</span><p className="eyebrow light">YAPILANDIRILMIŞ FİKİR KARTI</p><h1>{selected.problem}</h1><p>{selected.text}</p></div><div className="score-ring"><strong>{clarity}</strong><span>netlik puanı</span></div></div><div className="detail-grid"><div className="detail-card"><span>Problem</span><strong>{selected.problem}</strong></div><div className="detail-card"><span>Önerilen çözüm</span><strong>{selected.solution}</strong></div><div className="detail-card"><span>Hedef kitle</span><strong>{selected.audience}</strong></div><div className="detail-card"><span>Mevcut aşama</span><strong>{selected.stage}</strong></div></div><div className="panel"><div className="section-title"><div><p className="eyebrow">YETKİNLİK AÇIĞI</p><h3>Projeyi tamamlayacak roller</h3></div><button className="text-button" onClick={() => setActiveTab("Eşleşmeler")}>Adayları gör <Icon name="arrow" size={15} /></button></div><div className="skill-list">{selected.skills.map((skill, index) => <span key={skill}><b>{String(index + 1).padStart(2, "0")}</b>{skill}</span>)}</div></div></section>
            <aside className="analysis-side"><div className="panel synthesis-card"><p className="eyebrow">TEMSİLİ FİKİR SENTEZİ</p><h3>%87 benzerlikte tamamlayıcı fikir senaryosu</h3><div className="mini-profile"><span className="avatar cyan">ZK</span><div><strong>Zeynep Koç</strong><small>Örnek pilot profil</small></div></div><p>“Fizik deneylerini düşük donanımlı cihazlarda çalıştıran açık kaynak simülasyon seti...”</p><ul><li>Ortak hedef kitle</li><li>Tamamlayıcı içerik deneyimi</li><li>Birleşebilir teknik kapsam</li></ul><button className="primary-button full" onClick={() => setNotice("Birleşme daveti taslak olarak oluşturuldu. Gönderim için iki tarafın onayı gerekir.")}>Birleşme önerisi hazırla</button></div><div className="panel trust-card"><Icon name="shield" size={22} /><div><strong>Karar kullanıcıda</strong><p>AI önerileri açıklanır, düzenlenebilir ve açık onay olmadan hiçbir işlem yapılmaz.</p></div></div></aside>
          </div>
        )}

        {activeTab === "Eşleşmeler" && (
          <div className="matches-layout"><div className="matches-head"><div><p className="eyebrow">AÇIKLANABİLİR EŞLEŞTİRME</p><h1>Ekibini tamamlayacak kişiler</h1><p>Aday kartları bu prototipte temsili profillerdir. Pilot katılımcılar geldikçe gerçek eşleşme ölçümleri üretilecektir.</p></div><div className="formula"><span>Konu %30</span><span>Yetkinlik %30</span><span>Müsaitlik %15</span><span>Diğer %25</span></div></div><div className="candidate-grid">{candidates.map((candidate) => <article className="candidate-card" key={candidate.name}><div className="candidate-score">%{candidate.score}</div><span className="sample-label">Örnek profil</span><span className="avatar violet">{candidate.initials}</span><h3>{candidate.name}</h3><p>{candidate.role}</p><div className="reason-box"><span>Neden önerildi?</span><strong>{candidate.reason}</strong></div><button className={invited.includes(candidate.name) ? "invited-button" : "primary-button full"} onClick={() => setInvited((list) => list.includes(candidate.name) ? list : [...list, candidate.name])}>{invited.includes(candidate.name) ? <><Icon name="check" size={15} /> Davet hazırlandı</> : "Ekibe davet et"}</button></article>)}</div><div className="ethics-strip"><Icon name="shield" size={24} /><div><strong>Adil eşleşme tasarımı</strong><p>Takipçi sayısı puanlamaya dahil edilmez. Kullanıcı önerilerden çıkabilir, yetkinliklerini düzenleyebilir ve verisini silebilir.</p></div></div></div>
        )}

        {activeTab === "Proje Odası" && (
          <div className="project-layout"><section className="project-board"><div className="project-title-row"><div><p className="eyebrow">AKTİF DEMO PROJESİ</p><h1>Sanal Laboratuvar Erişim Projesi</h1><p>Fikir kartından ekip ve uygulanabilir yol haritasına.</p></div><span className="status-pill">Ekip kuruluyor</span></div><div className="progress-card"><div><span>İlk doğrulama planı</span><strong>{completed.length}/4 görev</strong></div><div className="progress-track"><span style={{ width: `${completed.length * 25}%` }} /></div></div><div className="roadmap-list">{roadmap.map((task, index) => <button className={`task-row ${completed.includes(index) ? "done" : ""}`} key={task.title} onClick={() => setCompleted((list) => list.includes(index) ? list.filter((item) => item !== index) : [...list, index])}><span className="check">{completed.includes(index) && <Icon name="check" size={13} />}</span><div><strong>{task.title}</strong><small>{task.owner}</small></div><b>{task.week}</b></button>)}</div></section><aside className="project-side"><div className="panel coach-panel"><p className="eyebrow light">AI PROJE KOÇU</p><h3>Sıradaki en doğru adım</h3><p>Çözümü geliştirmeden önce problem görüşmelerini tamamlayın. Başarı ölçütünü “öğrenci deneyi tamamlayabildi mi?” olarak tanımlayın.</p><button onClick={() => setNotice("Proje koçu önerisi görev listesine eklendi.")}>Görev olarak ekle <Icon name="arrow" size={15} /></button></div><div className="panel team-panel"><div className="section-title"><h3>Ekip</h3><span>3/5 kişi</span></div><div className="avatar-stack"><span className="avatar blue">DA</span><span className="avatar violet">SK</span><span className="avatar orange">AD</span><span className="avatar empty">+2</span></div><p>İçerik uzmanı ve kullanıcı araştırmacısı rolleri açık.</p></div></aside></div>
        )}
      </section>

      <nav className="mobile-nav" aria-label="Mobil navigasyon">{tabs.map((tab, index) => <button key={tab} className={activeTab === tab ? "active" : ""} onClick={() => setActiveTab(tab)}><Icon name={tabIcons[index]} size={20} /><span>{tab === "Proje Odası" ? "Proje" : tab}</span></button>)}<button className="mobile-compose" onClick={() => setComposerOpen(true)} aria-label="Yeni fikir"><Icon name="plus" size={22} /></button></nav>

      {composerOpen && <div className="modal-backdrop" onMouseDown={() => !submitting && setComposerOpen(false)}><form className="composer" onSubmit={createIdea} onMouseDown={(event) => event.stopPropagation()}><div className="composer-brand"><span className="nsosyal-mark small">N</span><span>NSosyal paylaşımını projeye dönüştür</span></div><div className="section-title"><div><p className="eyebrow">PİLOT VERİ GİRİŞİ</p><h2>Fikrini doğal şekilde anlat</h2></div><button type="button" className="close-button" onClick={() => setComposerOpen(false)} disabled={submitting}><Icon name="close" size={19} /></button></div><p>Problemi, düşündüğün çözümü veya aradığın desteği yaz. Sistem fikri yapılandırıp olası ekip rollerini çıkaracak.</p><textarea value={draft} onChange={(event) => setDraft(event.target.value)} placeholder="Örneğin: Üniversite öğrencilerinin alanında çalışan mentörlere ulaşmasını kolaylaştıracak..." autoFocus maxLength={4000} /><div className="composer-meta"><span>{draft.trim().length}/4000</span><span>En az 20 karakter</span></div><div className="consent-line"><Icon name="shield" size={20} /><p><strong>Açık rıza:</strong> Bu içerik yalnızca fikir analizi, pilot ölçüm ve ekip eşleştirme amacıyla işlenecektir.</p></div><div className="modal-actions"><button type="button" className="secondary-button" onClick={() => setComposerOpen(false)} disabled={submitting}>Vazgeç</button><button className="primary-button" type="submit" disabled={submitting}><Icon name="spark" size={16} />{submitting ? "Analiz ediliyor..." : "Analiz et ve kaydet"}</button></div></form></div>}
    </main>
  );
}
