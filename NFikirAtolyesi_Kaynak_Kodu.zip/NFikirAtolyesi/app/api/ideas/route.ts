import { desc } from "drizzle-orm";
import { getDb } from "../../../db";
import { auditEvents, ideas } from "../../../db/schema";
import { analyzeIdea } from "../../../lib/ai/idea-analysis";

export async function GET() {
  try {
    const db = getDb();
    const rows = await db.select().from(ideas).orderBy(desc(ideas.createdAt)).limit(50);
    return Response.json({ ideas: rows });
  } catch (error) {
    return Response.json({ error: error instanceof Error ? error.message : "Ideas unavailable" }, { status: 503 });
  }
}

export async function POST(request: Request) {
  try {
    const payload = (await request.json()) as { content?: string; ownerId?: string; ownerName?: string };
    const content = payload.content?.trim() ?? "";
    if (content.length < 20 || content.length > 4000) {
      return Response.json({ error: "content must be between 20 and 4000 characters" }, { status: 400 });
    }

    const analysis = analyzeIdea(content);
    const id = crypto.randomUUID();
    const ownerId = payload.ownerId?.trim() || "demo-emirhan";
    const ownerName = payload.ownerName?.trim() || "Emirhan Eken";
    const db = getDb();

    await db.batch([
      db.insert(ideas).values({
        id,
        ownerId,
        ownerName,
        content,
        problem: analysis.problem,
        solution: analysis.solution,
        targetAudience: analysis.targetAudience,
        domain: analysis.domain,
        skillsJson: JSON.stringify(analysis.skills),
      }),
      db.insert(auditEvents).values({
        actorId: ownerId,
        action: "idea.created",
        entityType: "idea",
        entityId: id,
        metadataJson: JSON.stringify({ source: "prototype", consent: true }),
      }),
    ]);

    return Response.json({ idea: { id, content, ...analysis } }, { status: 201 });
  } catch (error) {
    return Response.json({ error: error instanceof Error ? error.message : "Idea could not be created" }, { status: 500 });
  }
}
