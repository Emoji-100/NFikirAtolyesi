import NFikirClient from "./nfikir-client";

export default function Home() {
  return <NFikirClient />;
}
