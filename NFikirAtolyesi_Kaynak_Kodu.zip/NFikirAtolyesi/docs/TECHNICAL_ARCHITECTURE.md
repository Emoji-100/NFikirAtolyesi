# NFikirAtölyesi Teknik Mimari

## Entegrasyon durumu

20 Ağustos 2026 tarihinde yapılan açık kaynak taramasında NSosyal için resmî ve herkese açık bir geliştirici API'si, OAuth kapsamları veya webhook sözleşmesi bulunamadı. Bu nedenle prototip hiçbir özel uç nokta tahmini yapmaz ve izinsiz veri çekmez. `lib/nsosyal/NSosyalPort` uygulama ile platform arasındaki sınırdır. Resmî sözleşme alındığında yalnızca `OfficialNSosyalAdapter` tamamlanır.

## Üretim topolojisi

1. **NSosyal istemcisi:** Kullanıcı bir paylaşımda “Projeye dönüştür” seçeneğini açar ve açık rıza verir.
2. **Entegrasyon ağ geçidi:** OAuth 2.1 + PKCE, kapsam kontrolü, webhook HMAC doğrulaması, idempotency anahtarı ve hız sınırlaması uygular.
3. **Fikir servisi:** Paylaşımı yapılandırılmış fikir kartına dönüştürür ve kullanıcının düzenlemesine sunar.
4. **AI orkestratörü:** Türkçe problem/çözüm/hedef kitle çıkarımı, embedding üretimi, benzer fikir araması, yetkinlik açığı ve yol haritası üretimini yönetir.
5. **Eşleştirme servisi:** Konu uyumu, yetkinlik tamamlayıcılığı, müsaitlik ve çalışma tercihlerini açıklanabilir puana dönüştürür.
6. **Proje servisi:** Ekip, davet, görev, yol haritası ve ilerleme kayıtlarını yönetir.
7. **Veri katmanı:** İlişkisel kayıtlar için PostgreSQL/D1; anlamsal arama için pgvector veya yönetilen vektör veritabanı; medya için nesne depolama; kısa süreli kuyruk ve önbellek için Redis/KV kullanır.

## API sınırları

- `POST /v1/ideas/from-post`: Açık rıza verilen NSosyal paylaşımını fikir kartına dönüştürür.
- `PATCH /v1/ideas/:id`: AI çıktısını kullanıcı düzeltmeleriyle günceller.
- `GET /v1/ideas/:id/similar`: Benzer ve tamamlayıcı fikirleri açıklamalarıyla döndürür.
- `GET /v1/ideas/:id/candidates`: Ekip adaylarını puan bileşenleriyle döndürür.
- `POST /v1/projects`: Onaylanan fikirlerden proje odası açar.
- `POST /v1/projects/:id/roadmap`: Düzenlenebilir başlangıç planı üretir.
- `POST /v1/nsosyal/events`: İmzalı ve tekrar oynatma korumalı platform olaylarını alır.

Tüm yazma isteklerinde `Idempotency-Key`, kullanıcı yetki kapsamı ve sunucu tarafı sahiplik kontrolü zorunludur.

## AI hattı

1. Açık rıza ve veri minimizasyonu kontrolü
2. PII ve güvenlik filtresi
3. Türkçe içerik sınıflandırma ve yapılandırılmış JSON çıkarımı
4. Çok dilli embedding ve vektör aday üretimi
5. İkinci aşama çapraz kodlayıcı ile benzerlik sıralaması
6. Yetkinlik açığı ve tamamlayıcılık skoru
7. Şema doğrulamalı yol haritası üretimi
8. Kullanıcı onayı ve düzeltme kaydı

Eşleştirme skoru başlangıçta `0.30 konu + 0.30 yetkinlik tamamlayıcılığı + 0.15 müsaitlik + 0.10 deneyim + 0.10 çalışma tercihi + 0.05 konum` olarak hesaplanır. Takipçi sayısı kullanılmaz. Katsayılar çevrim dışı değerlendirme ve kullanıcı araştırmasıyla kalibre edilir.

## Güvenlik ve KVKK

- Yalnızca kullanıcının açıkça projeye dönüştürdüğü paylaşımlar analiz edilir.
- Platform erişim belirteçleri tarayıcıya gönderilmez ve şifreli gizli değer deposunda tutulur.
- Hassas veriler loglardan çıkarılır; denetim kayıtları değiştirilemez biçimde saklanır.
- Kullanıcı eşleştirmeden çıkabilir, verisini düzeltebilir ve silebilir.
- Webhook imzası, zaman damgası ve nonce doğrulanır; olaylar idempotent işlenir.
- Her servis minimum yetkiyle çalışır; yönetici işlemleri ayrı rol ve çok faktörlü doğrulama ister.
- Model çıktıları öneridir. Otomatik ekip kurma, davet gönderme veya proje birleştirme yapılmaz.

## Dayanıklılık

- Dış platform kesintilerinde olaylar kuyrukta tekrar denenir; üstel geri çekilme ve dead-letter queue kullanılır.
- Devre kesici, zaman aşımı ve oran sınırlama ile NSosyal tarafındaki sorun uygulamaya yayılmaz.
- İstek ve olaylarda izlenebilirlik kimliği bulunur; ölçümler, yapılandırılmış loglar ve dağıtık izleme birlikte kullanılır.
- Veritabanı yedekleri, geri yükleme tatbikatı ve şema göçleri için geri alma planı tutulur.
- Hedefler: aylık %99,9 kullanılabilirlik, çekirdek API için p95 < 400 ms, AI görevleri için asenkron ilerleme durumu.

## Canlı entegrasyon öncesi zorunlu girdiler

1. Resmî API taban adresi ve sürümleme politikası
2. OAuth yetkilendirme adresleri, istemci kimliği ve izin kapsamları
3. Gönderi, profil ve proje kartı veri sözleşmeleri
4. Webhook olay tipleri, imza yöntemi ve tekrar gönderim politikası
5. Hız limitleri, saklama koşulları ve yarışma ekibine açılan test ortamı
6. NSosyal güvenlik ve KVKK inceleme onayı

Bu girdiler olmadan “canlı NSosyal entegrasyonu” yapıldığı iddia edilmemeli; mevcut prototip entegrasyona hazır, güvenli ve sözleşme odaklıdır.
