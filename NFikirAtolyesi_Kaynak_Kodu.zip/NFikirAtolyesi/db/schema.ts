import { sql } from "drizzle-orm";
import { integer, sqliteTable, text } from "drizzle-orm/sqlite-core";

export const ideas = sqliteTable("ideas", {
  id: text("id").primaryKey(),
  nsosyalPostId: text("nsosyal_post_id").unique(),
  ownerId: text("owner_id").notNull(),
  ownerName: text("owner_name").notNull(),
  content: text("content").notNull(),
  problem: text("problem").notNull(),
  solution: text("solution").notNull(),
  targetAudience: text("target_audience").notNull(),
  domain: text("domain").notNull(),
  stage: text("stage").notNull().default("Fikir"),
  skillsJson: text("skills_json").notNull().default("[]"),
  consentStatus: text("consent_status").notNull().default("granted"),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  updatedAt: text("updated_at").notNull().default(sql`CURRENT_TIMESTAMP`),
});

export const projects = sqliteTable("projects", {
  id: text("id").primaryKey(),
  ideaId: text("idea_id").notNull(),
  title: text("title").notNull(),
  status: text("status").notNull().default("forming"),
  roadmapJson: text("roadmap_json").notNull().default("[]"),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  updatedAt: text("updated_at").notNull().default(sql`CURRENT_TIMESTAMP`),
});

export const auditEvents = sqliteTable("audit_events", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  actorId: text("actor_id").notNull(),
  action: text("action").notNull(),
  entityType: text("entity_type").notNull(),
  entityId: text("entity_id").notNull(),
  metadataJson: text("metadata_json").notNull().default("{}"),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
});
