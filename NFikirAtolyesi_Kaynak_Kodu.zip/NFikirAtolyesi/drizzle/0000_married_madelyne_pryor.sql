CREATE TABLE `audit_events` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`actor_id` text NOT NULL,
	`action` text NOT NULL,
	`entity_type` text NOT NULL,
	`entity_id` text NOT NULL,
	`metadata_json` text DEFAULT '{}' NOT NULL,
	`created_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL
);
--> statement-breakpoint
CREATE TABLE `ideas` (
	`id` text PRIMARY KEY NOT NULL,
	`nsosyal_post_id` text,
	`owner_id` text NOT NULL,
	`owner_name` text NOT NULL,
	`content` text NOT NULL,
	`problem` text NOT NULL,
	`solution` text NOT NULL,
	`target_audience` text NOT NULL,
	`domain` text NOT NULL,
	`stage` text DEFAULT 'Fikir' NOT NULL,
	`skills_json` text DEFAULT '[]' NOT NULL,
	`consent_status` text DEFAULT 'granted' NOT NULL,
	`created_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL,
	`updated_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `ideas_nsosyal_post_id_unique` ON `ideas` (`nsosyal_post_id`);--> statement-breakpoint
CREATE TABLE `projects` (
	`id` text PRIMARY KEY NOT NULL,
	`idea_id` text NOT NULL,
	`title` text NOT NULL,
	`status` text DEFAULT 'forming' NOT NULL,
	`roadmap_json` text DEFAULT '[]' NOT NULL,
	`created_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL,
	`updated_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL
);
